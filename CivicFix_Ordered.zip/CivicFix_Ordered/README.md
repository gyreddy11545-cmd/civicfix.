# CivicFix — ordered project files

## Root-file order
1. `requirements.txt` — Python dependencies
2. `.env.example` — example environment configuration; change the sample secret key before production
3. `schema.sql` — SQLite database schema
4. `civicfix.db` — supplied demo database
5. `seed_data.py` — rebuilds and seeds demo data; **warning:** it deletes an existing `civicfix.db` before rebuilding it
6. `generate_demo_images.py` — creates demo images under `app/static/uploads/`
7. `run.py` — application entry point; imports `create_app` from the `app` package

## Important
The uploaded files do not include the `app/` package. Add your actual `app/__init__.py`, routes, templates, static assets, and any other modules the app imports before running or deploying. Do not replace your existing application code with empty placeholder folders.

## Local setup
1. Create and activate a Python virtual environment.
2. Install dependencies: `pip install -r requirements.txt`
3. Add the missing `app/` application package.
4. Run `python generate_demo_images.py` if the application expects the demo images.
5. Start with `python run.py`.

For public deployment, configure a strong secret key through environment variables, turn off debug mode, and confirm the hosting platform supports persistent storage if you rely on SQLite and local uploads.
